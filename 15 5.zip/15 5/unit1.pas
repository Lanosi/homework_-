unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, LazUTF8;

type
  TPStudent = ^TStudent; // указатель на тип TPStudent
  TStudent = record
    fam: string[20]; // фамилия
    name: string[20]; // имя
    next: TPStudent;  // следующий элемент списка
  end;

  { TForm1 }
  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Edit1: TEdit;
    Edit2: TEdit;
    Label1: TLabel;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure Label1Click(Sender: TObject);
  private
  public
  end;

var
  Form1: TForm1;
  head: TPStudent;  // начало (голова) списка

implementation

{$R *.lfm}
function HasDigits(s: string): boolean;
var
  i: integer;
begin
  Result := false;
  for i := 1 to Length(s) do
    if s[i] in ['0'..'9'] then
    begin
      Result := true;
      Exit;
    end;
end;
function SaveToFile: boolean;
var
  f: TextFile;
  tek: TPStudent;
begin
  Result := false;

  try
    AssignFile(f, 'students.txt');
    Rewrite(f);

    tek := head;
    while tek <> nil do
    begin
      Writeln(f, tek^.fam + '|' + tek^.name);
      tek := tek^.next;
    end;

    CloseFile(f);
    Result := true; // ✔ успех
  except
    on E: Exception do
    begin
      ShowMessage(
        'Ошибка сохранения!' + #13 +
        'Файл недоступен для записи.' + #13 +
        'Закройте файл или обратитесь к администратору.'
      );
    end;
  end;
end;
procedure LoadFromFile;
var
  f: TextFile;
  s, fam, name: string;
  p: integer;
  nov: TPStudent;
begin
  if not FileExists('students.txt') then Exit;

  AssignFile(f, 'students.txt');
  Reset(f);

  while not EOF(f) do
  begin
    Readln(f, s);
    p := Pos('|', s);

    fam := Copy(s, 1, p-1);
    name := Copy(s, p+1, Length(s));

    New(nov);
    nov^.fam := fam;
    nov^.name := name;
    nov^.next := head;
    head := nov;
  end;

  CloseFile(f);
end;
procedure TForm1.FormCreate(Sender: TObject);
begin
  head := nil; // ← инициализация при создании формы
  LoadFromFile;
end;

procedure TForm1.Label1Click(Sender: TObject);
begin

end;


procedure TForm1.Button1Click(Sender: TObject);
var
  nov, tek: TPStudent; // новый элемент списка
  found: boolean;
begin
  Edit1.Text := Trim(Edit1.Text);   //Удаление пробелов
  Edit2.Text := Trim(Edit2.Text);   //Удаление пробелов

  if (Edit1.Text = '') or (Edit2.Text = '') then
begin
  ShowMessage('Введите имя и фамилию');
  Exit;
end;

if HasDigits(Edit1.Text) or HasDigits(Edit2.Text) then
begin
  ShowMessage('Цифры вводить нельзя');
  Exit;
end;
  tek := head;
  found := false;

  while tek <> nil do
  begin
    if (UTF8LowerCase(tek^.fam) = UTF8LowerCase(Edit1.Text)) and
       (UTF8LowerCase(tek^.name) = UTF8LowerCase(Edit2.Text)) then
    begin
      found := true;
      break;
    end;
    tek := tek^.next;
  end;

  if found then
  begin
    ShowMessage('Такой студент уже есть');
    Exit;
  end;

  new(nov);
  nov^.fam := Edit1.Text;
  nov^.name := Edit2.Text;
  nov^.next := head;
  head := nov;

  // пробуем сохранить
  if not SaveToFile then
  begin
  //  откат
    head := nov^.next;
    Dispose(nov);
    Exit;
  end;

// ✔ только если всё ок — очищаем поля
  Edit1.Text := '';
  Edit2.Text := '';
  Edit1.SetFocus;
  end;


procedure TForm1.Button2Click(Sender: TObject);
var
  tek, pre: TPStudent;
  found: boolean;
  oldNext: TPStudent;   // ← добавить эту переменную
begin
  if head = nil then
  begin
    ShowMessage('Список ещё пустой');
    Exit;
  end;

  tek := head;
  pre := nil;
  found := false;

  while tek <> nil do
  begin
    if (UTF8LowerCase(tek^.fam) = UTF8LowerCase(Edit1.Text)) and
       (UTF8LowerCase(tek^.name) = UTF8LowerCase(Edit2.Text)) then
    begin
      found := true;
      break;
    end;
    pre := tek;
    tek := tek^.next;
  end;

  if not found then
  begin
    ShowMessage('Такого студента нет');
    Exit;
  end;

  // блок удаления

  oldNext := tek^.next;


  if pre = nil then
    head := tek^.next
  else
    pre^.next := tek^.next;


  if not SaveToFile then
  begin
    // откат
    if pre = nil then
      head := tek
    else
      pre^.next := tek;

    tek^.next := oldNext;

    ShowMessage('Ошибка! Удаление отменено.');
    Exit;
  end;


  Dispose(tek);


  ShowMessage('Студент удалён');

  Edit1.Text := '';
  Edit2.Text := '';
  Edit1.SetFocus;
end;

procedure TForm1.Button3Click(Sender: TObject);
var
  tek: TPStudent;
  st: string;
begin
  st := '';
  tek := head;

  while tek <> nil do
  begin
    st := st + tek^.fam + ' ' + tek^.name + #13;
    tek := tek^.next;
  end;

  if st = '' then
    ShowMessage('Список студентов пуст')
  else
    ShowMessage('Список:' + #13 + st);
end;

end.
